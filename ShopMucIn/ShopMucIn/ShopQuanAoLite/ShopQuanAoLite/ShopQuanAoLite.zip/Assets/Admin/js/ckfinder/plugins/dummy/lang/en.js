﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see license.txt or http://cksource.com/ckfinder/license
*/

CKFinder.setPluginLang( 'dummy', 'en',
{
	dummy :
	{
		title : 'Dummy dialog',
		menuItem : 'Open dummy dialog',
		typeText : 'Please type some text.'
	}
});
